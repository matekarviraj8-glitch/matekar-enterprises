var IMG={button:"images/button.jpg",oyster:"images/oyster.jpg"};
var P=[{id:"button",n:"Button mushrooms",p:200,d:"Mild and firm. Good for curries, soups and pizza."},
{id:"oyster",n:"Oyster mushrooms",p:250,d:"Soft and quick to cook. Best sautéed with garlic."},
{id:"milky",n:"Milky mushrooms",p:220,d:"Thick white stems. Hold their shape in gravies.",c:"#EFEAE0"},
{id:"dried",n:"Dried mushrooms",p:900,d:"Long shelf life. Soak 20 minutes before cooking.",c:"#A5782F"}];
var cart={},$=function(i){return document.getElementById(i)},R=function(n){return "₹ "+n.toLocaleString("en-IN")};
function ph(p){return IMG[p.id]?'<img src="'+IMG[p.id]+'" alt="'+p.n+'" loading="lazy">':'<svg viewBox="0 0 120 110" aria-hidden="true"><rect x="50" y="58" width="20" height="44" rx="9" fill="var(--bg)" stroke="var(--ink)" stroke-width="3"/><path d="M10 66C10 10 110 10 110 66Z" fill="'+p.c+'" stroke="var(--ink)" stroke-width="3"/></svg>'}
$("grid").innerHTML=P.map(function(p){return '<article class="card"><div class="ph">'+ph(p)+'</div><div class="b"><h3>'+p.n+'</h3><p>'+p.d+'</p><div class="price">'+R(p.p)+' <small>/ kg</small></div><div class="q"><button data-k="'+p.id+'" data-d="-0.5" aria-label="Less">−</button><output id="q-'+p.id+'">1 kg</output><button data-k="'+p.id+'" data-d="0.5" aria-label="More">+</button></div><button class="btn" data-add="'+p.id+'">Click to order</button></div></article>'}).join("");
var sel={button:1,oyster:1,milky:1,dried:1};
function find(id){return P.filter(function(p){return p.id===id})[0]}
function toast(t){var e=$("toast");e.textContent=t;e.classList.add("on");clearTimeout(toast.t);toast.t=setTimeout(function(){e.classList.remove("on")},1600)}
function draw(){var ids=Object.keys(cart),sum=0,kg=0;
$("items").innerHTML=ids.length?ids.map(function(i){var p=find(i),q=cart[i];sum+=p.p*q;kg+=q;return '<div class="ci"><div><b>'+p.n+'</b><div class="empty">'+R(p.p)+' / kg</div></div><div class="c"><button data-c="'+i+'" data-d="-0.5" aria-label="Less">−</button><output>'+q+' kg</output><button data-c="'+i+'" data-d="0.5" aria-label="More">+</button></div><div class="empty">'+R(p.p*q)+'</div><button class="rm" data-rm="'+i+'">Remove</button></div>'}).join(""):'<p class="empty">Your order box is empty. Tap “Click to order” on any mushroom.</p>';
$("total").textContent=R(sum);$("bar").classList.toggle("on",ids.length>0);$("bt").textContent=ids.length+" item"+(ids.length>1?"s":"")+" · "+R(sum)}
document.addEventListener("click",function(e){var t=e.target.closest("button");if(!t)return;
if(t.dataset.k){var k=t.dataset.k;sel[k]=Math.max(.5,sel[k]+ +t.dataset.d);$("q-"+k).textContent=sel[k]+" kg"}
else if(t.dataset.add){var a=t.dataset.add;cart[a]=(cart[a]||0)+sel[a];draw();toast(find(a).n+" added")}
else if(t.dataset.c){var c=t.dataset.c;cart[c]=cart[c]+ +t.dataset.d;if(cart[c]<=0)delete cart[c];draw()}
else if(t.dataset.rm){delete cart[t.dataset.rm];draw()}
else if(t.dataset.a){setA(t.dataset.a)}});
function setA(a){document.documentElement.dataset.accent=a;[].forEach.call(document.querySelectorAll(".sw"),function(s){s.setAttribute("aria-pressed",s.dataset.a===a)});try{localStorage.setItem("mk-a",a)}catch(e){}}
$("mode").onclick=function(){var d=document.documentElement,dark=d.dataset.theme?d.dataset.theme==="dark":matchMedia("(prefers-color-scheme:dark)").matches;d.dataset.theme=dark?"light":"dark";try{localStorage.setItem("mk-t",d.dataset.theme)}catch(e){}};
try{var sa=localStorage.getItem("mk-a"),st=localStorage.getItem("mk-t");if(st)document.documentElement.dataset.theme=st;setA(sa||"green")}catch(e){setA("green")}
$("send").onclick=function(){var ids=Object.keys(cart),n=$("nm").value.trim(),p=$("ph").value.replace(/\D/g,""),a=$("ad").value.trim(),er=$("err");
if(!ids.length)return er.textContent="Please add at least one mushroom first.";
if(!n||p.length<10||!a)return er.textContent="Please fill your name, a 10-digit phone number and address.";
er.textContent="";var s=0,l=ids.map(function(i){var q=find(i),k=cart[i];s+=q.p*k;return "• "+q.n+": "+k+" kg = "+R(q.p*k)}).join("\n");
var m="Hello Matekar Enterprises, I want to order:\n\n"+l+"\n\nTotal: "+R(s)+"\n\nName: "+n+"\nPhone: "+p+"\nAddress: "+a;
window.open("https://wa.me/919137296719?text="+encodeURIComponent(m),"_blank")};
draw();
